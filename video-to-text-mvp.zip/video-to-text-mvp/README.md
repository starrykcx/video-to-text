# 视频转文字（零基础可部署）

这是一个最小可用的网站：上传视频/音频，调用转写模型，输出为 纯文本 / SRT / VTT / JSON。

## 快速开始（无需本地安装）
1. 在 GitHub 新建一个空仓库（New -> 取名 `video-to-text`）。
2. 把本项目里的所有文件上传到仓库的根目录（Add file -> Upload files）。
3. 打开 Vercel，New Project -> 选择该 GitHub 仓库 -> Import。
4. 在 Vercel 项目 Settings -> Environment Variables 里新增：
   - `OPENAI_API_KEY` = 你的密钥
5. 点击 Deploy。部署完成后，访问生成的网址即可使用。

## 本地运行（可选）
- 本机需要 Node.js 18+
- 运行：
```bash
npm install
npm run dev
```
- 把 `OPENAI_API_KEY=...` 写到项目根目录的 `.env.local`（自行创建）
