export const runtime = "nodejs";

export async function POST(req) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    const response_format = form.get("response_format") || "text";

    if (!file || !file.stream) {
      return new Response("未收到文件", { status: 400 });
    }

    const upstream = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: (() => {
        const fd = new FormData();
        fd.append("file", file, file.name || "upload.mp4");
        fd.append("model", "gpt-4o-mini-transcribe");
        fd.append("response_format", response_format); // text | srt | vtt | json | verbose_json
        return fd;
      })()
    });

    if (!upstream.ok) {
      const errText = await upstream.text();
      return new Response(`上游错误：${errText}`, { status: 500 });
    }

    if (response_format === "verbose_json" || response_format === "json") {
      const data = await upstream.json();
      return Response.json(data);
    } else {
      const text = await upstream.text();
      const headers =
        response_format === "srt" || response_format === "vtt"
          ? {
              "Content-Type": "text/plain; charset=utf-8",
              "Content-Disposition": `attachment; filename="transcript.${response_format}"`
            }
          : { "Content-Type": "text/plain; charset=utf-8" };
      return new Response(text, { headers });
    }
  } catch (e) {
    return new Response(`服务器异常：${e.message}`, { status: 500 });
  }
}
