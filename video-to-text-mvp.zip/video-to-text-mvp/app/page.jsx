"use client";
import { useState } from "react";

export default function Home() {
  const [file, setFile] = useState(null);
  const [format, setFormat] = useState("text"); // text | srt | vtt | verbose_json
  const [loading, setLoading] = useState(false);
  const [output, setOutput] = useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!file) return alert("请选择一个视频文件");

    const form = new FormData();
    form.append("file", file);
    form.append("response_format", format);
    setLoading(true);
    setOutput("");

    try {
      const res = await fetch("/api/transcribe", {
        method: "POST",
        body: form
      });

      if (!res.ok) {
        const err = await res.text();
        throw new Error(err || "转写失败");
      }

      if (format === "verbose_json") {
        const data = await res.json();
        setOutput(JSON.stringify(data, null, 2));
      } else {
        const text = await res.text();
        setOutput(text);
      }
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen p-6 flex flex-col items-center gap-6">
      <h1 className="text-2xl font-bold">视频转文字（MVP）</h1>

      <form onSubmit={onSubmit} className="flex flex-col gap-3 w-full max-w-xl">
        <input
          type="file"
          accept="video/*,audio/*"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
        />

        <label className="text-sm">
          输出格式：
          <select
            value={format}
            onChange={(e) => setFormat(e.target.value)}
            className="ml-2 border p-1"
          >
            <option value="text">纯文本（text）</option>
            <option value="srt">字幕（.srt）</option>
            <option value="vtt">字幕（.vtt）</option>
            <option value="verbose_json">带时间戳 JSON</option>
          </select>
        </label>

        <button
          disabled={loading}
          className="bg-black text-white px-4 py-2 rounded"
        >
          {loading ? "正在转写..." : "开始转写"}
        </button>
      </form>

      <section className="w-full max-w-xl">
        <h2 className="font-semibold mb-2">结果</h2>
        <pre className="whitespace-pre-wrap break-words border p-3 rounded min-h-40">
          {output || "（等待结果）"}
        </pre>
      </section>
    </main>
  );
}
